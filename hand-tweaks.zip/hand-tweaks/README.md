# Hand Tweaks (Fabric, Minecraft 26.3)

Stellt Größe, Neigung und Position der Items in deiner Hand ein – getrennt für Haupt- und Nebenhand, mit einem cleanen Schwarz-Weiß-Menü.

## Bedienung

- **H** drücken (in *Optionen → Steuerung → Sonstiges* änderbar) → Menü öffnet sich links, rechts siehst du deine Hand live.
- Oben bzw. in der Seitenleiste zwischen **Haupthand** und **Nebenhand** wechseln (die Seitenleiste zeigt das Item, das du gerade hältst).
- **Größe**: Skalierung 0.1× – 3.0×, Schalter rechts aktiviert/deaktiviert die Hand.
- **Neigung**: X / Y / Z von −180° bis 180°.
- **Position**: X / Y / Z von −1 bis +1 (in Blöcken).
- Rechtsklick auf einen Regler = Standardwert, Mausrad = in kleinen Schritten.
- **Hände koppeln**: Änderungen gelten für beide Hände.
- **Auch in 3rd Person**: wendet die Werte auch auf deinen eigenen Spieler in F5 an.
- Für die linke Hand werden X-Position und Y/Z-Neigung automatisch gespiegelt, damit gleiche Werte symmetrisch aussehen.
- Seitenleiste unten: Mod an/aus. ↺-Icon: aktuelle Hand zurücksetzen.

Einstellungen werden beim Schließen in `.minecraft/config/handtweaks.json` gespeichert.

## Bauen

Du brauchst **JDK 25** (z. B. Temurin 25).

```bash
./gradlew build          # Windows: gradlew.bat build
```

Die fertige Mod liegt dann in `build/libs/hand-tweaks-1.0.0.jar`. Zusammen mit **Fabric API** (für 26.3) in `.minecraft/mods` legen.

Zum Testen direkt aus dem Projekt: `./gradlew runClient`.

## Projektstruktur

```
src/client/java/dev/handtweaks/
  HandTweaksClient.java      Einstieg, Tastenbelegung
  HandTweaksConfig.java      Einstellungen (JSON)
  HandTransform.java         Rechnet Größe/Neigung/Position auf das Item
  mixin/FirstPersonHandsAndItemsRendererMixin.java   1st Person
  mixin/ItemInHandLayerMixin.java                    3rd Person (eigener Spieler)
  gui/HandTweaksScreen.java  Das Menü
  gui/Ui.java                Zeichen-Helfer (runde Ecken, Pixel-Icons, Farben)
```

Farben anpassen: Konstanten oben in `gui/Ui.java`.
