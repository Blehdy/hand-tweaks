package dev.handtweaks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Alle Einstellungen der Mod. Wird als JSON in config/handtweaks.json gespeichert. */
public final class HandTweaksConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("handtweaks.json");
	private static HandTweaksConfig instance = new HandTweaksConfig();

	/** Werte für eine Hand. Rotation in Grad, Position in Blöcken. */
	public static final class Hand {
		public boolean enabled = true;
		public float scale = 1.0F;
		public float rotX = 0.0F;
		public float rotY = 0.0F;
		public float rotZ = 0.0F;
		public float posX = 0.0F;
		public float posY = 0.0F;
		public float posZ = 0.0F;

		public void copyFrom(Hand o) {
			enabled = o.enabled;
			scale = o.scale;
			rotX = o.rotX;
			rotY = o.rotY;
			rotZ = o.rotZ;
			posX = o.posX;
			posY = o.posY;
			posZ = o.posZ;
		}

		public void reset() {
			copyFrom(new Hand());
		}

		public boolean isDefault() {
			return scale == 1.0F && rotX == 0 && rotY == 0 && rotZ == 0 && posX == 0 && posY == 0 && posZ == 0;
		}
	}

	public boolean enabled = true;
	/** Änderungen an einer Hand werden gespiegelt auf die andere übernommen. */
	public boolean linkHands = false;
	/** Auch in der 3rd-Person-Ansicht (nur dein eigener Spieler) anwenden. */
	public boolean thirdPerson = false;
	public Hand mainHand = new Hand();
	public Hand offHand = new Hand();

	public static HandTweaksConfig get() {
		return instance;
	}

	public static void load() {
		if (Files.exists(FILE)) {
			try (Reader r = Files.newBufferedReader(FILE)) {
				HandTweaksConfig loaded = GSON.fromJson(r, HandTweaksConfig.class);
				if (loaded != null) {
					if (loaded.mainHand == null) loaded.mainHand = new Hand();
					if (loaded.offHand == null) loaded.offHand = new Hand();
					instance = loaded;
				}
			} catch (Exception e) {
				HandTweaksClient.LOGGER.warn("Konnte handtweaks.json nicht laden, nutze Standardwerte", e);
			}
		}
	}

	public static void save() {
		try {
			Files.createDirectories(FILE.getParent());
			try (Writer w = Files.newBufferedWriter(FILE)) {
				GSON.toJson(instance, w);
			}
		} catch (Exception e) {
			HandTweaksClient.LOGGER.warn("Konnte handtweaks.json nicht speichern", e);
		}
	}
}
