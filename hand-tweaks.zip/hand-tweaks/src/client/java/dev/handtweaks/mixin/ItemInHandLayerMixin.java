package dev.handtweaks.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.handtweaks.HandTransform;
import dev.handtweaks.HandTweaksConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.renderer.entity.state.ArmedEntityRenderState;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 3rd-Person (optional): nur für den eigenen Spieler. */
@Mixin(ItemInHandLayer.class)
public abstract class ItemInHandLayerMixin {
	@Unique
	private static final String SUBMIT = "Lnet/minecraft/client/renderer/item/ItemStackRenderState;submit("
			+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;III)V";

	@Unique
	private boolean handtweaks$pushed;

	@Inject(method = "submitArmWithItem", at = @At(value = "INVOKE", target = SUBMIT, shift = At.Shift.BEFORE))
	private void handtweaks$before(ArmedEntityRenderState state, ItemStackRenderState itemState, ItemStack itemStack,
			HumanoidArm arm, PoseStack poseStack, SubmitNodeCollector collector, int lightCoords, CallbackInfo ci) {
		handtweaks$pushed = false;
		if (!HandTweaksConfig.get().thirdPerson) {
			return;
		}

		Minecraft mc = Minecraft.getInstance();
		boolean self = mc.player != null && state instanceof AvatarRenderState avatar && avatar.id == mc.player.getId();
		if (self) {
			handtweaks$pushed = HandTransform.push(poseStack, HandTransform.handOf(arm), itemStack);
		}
	}

	@Inject(method = "submitArmWithItem", at = @At(value = "INVOKE", target = SUBMIT, shift = At.Shift.AFTER))
	private void handtweaks$after(ArmedEntityRenderState state, ItemStackRenderState itemState, ItemStack itemStack,
			HumanoidArm arm, PoseStack poseStack, SubmitNodeCollector collector, int lightCoords, CallbackInfo ci) {
		if (handtweaks$pushed) {
			poseStack.popPose();
			handtweaks$pushed = false;
		}
	}
}
