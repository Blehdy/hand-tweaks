package dev.handtweaks.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.handtweaks.HandTransform;
import net.minecraft.client.renderer.FirstPersonHandsAndItemsRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.FirstPersonHandsAndItemsRenderState;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** First-Person: transformiert das Item direkt vor dem Zeichnen. */
@Mixin(FirstPersonHandsAndItemsRenderer.class)
public abstract class FirstPersonHandsAndItemsRendererMixin {
	@Unique
	private static final String SUBMIT = "Lnet/minecraft/client/renderer/item/ItemStackRenderState;submit("
			+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;III)V";

	@Unique
	private boolean handtweaks$pushed;

	@Inject(method = "submitArmWithItem", at = @At(value = "INVOKE", target = SUBMIT, shift = At.Shift.BEFORE))
	private void handtweaks$before(PlayerRenderState playerState, FirstPersonHandsAndItemsRenderState state,
			float partialTicks, float xRot, InteractionHand hand, float attack, ItemStack itemStack,
			float inverseArmHeight, PoseStack poseStack, SubmitNodeCollector submitNodeCollector,
			int lightCoords, CallbackInfo ci) {
		handtweaks$pushed = HandTransform.push(poseStack, hand, itemStack);
	}

	@Inject(method = "submitArmWithItem", at = @At(value = "INVOKE", target = SUBMIT, shift = At.Shift.AFTER))
	private void handtweaks$after(PlayerRenderState playerState, FirstPersonHandsAndItemsRenderState state,
			float partialTicks, float xRot, InteractionHand hand, float attack, ItemStack itemStack,
			float inverseArmHeight, PoseStack poseStack, SubmitNodeCollector submitNodeCollector,
			int lightCoords, CallbackInfo ci) {
		if (handtweaks$pushed) {
			poseStack.popPose();
			handtweaks$pushed = false;
		}
	}
}
