package dev.handtweaks;

import com.mojang.blaze3d.platform.InputConstants;
import dev.handtweaks.gui.HandTweaksScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.sdl.SDLScancode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class HandTweaksClient implements ClientModInitializer {
	public static final String MOD_ID = "handtweaks";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/** Standardtaste: H (in den Steuerungs-Einstellungen änderbar). */
	public static final KeyMapping OPEN_KEY = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.handtweaks.open", InputConstants.Type.KEYBOARD, SDLScancode.SDL_SCANCODE_H, KeyMapping.Category.MISC));

	@Override
	public void onInitializeClient() {
		HandTweaksConfig.load();

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (OPEN_KEY.consumeClick()) {
				if (client.player != null && client.gui.screen() == null) {
					client.gui.setScreen(new HandTweaksScreen());
				}
			}
		});
	}
}
