package dev.handtweaks.gui;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Kleine Zeichen-Helfer für das Schwarz-Weiß-Design (abgerundete Flächen, Pixel-Icons). */
final class Ui {
	// Farbpalette – nur Schwarz, Weiß und Grautöne
	static final int PANEL = 0xE0121212;
	static final int CARD = 0x14FFFFFF;
	static final int CARD_HOVER = 0x1CFFFFFF;
	static final int CHIP = 0x1FFFFFFF;
	static final int CHIP_HOVER = 0x33FFFFFF;
	static final int TRACK = 0x33FFFFFF;
	static final int WHITE = 0xFFFFFFFF;
	static final int TEXT = 0xFFF2F2F2;
	static final int LABEL = 0xFFA0A0A0;
	static final int MUTED = 0xFF6E6E6E;
	static final int BLACK = 0xFF0E0E0E;

	static final String[] ICON_POWER = {
			"....#....",
			".#..#..#.",
			"#...#...#",
			"#...#...#",
			"#.......#",
			"#.......#",
			".#.....#.",
			"..#####.."
	};

	static final String[] ICON_RESET = {
			"..####.#.",
			".#....##.",
			"#....###.",
			"#........",
			"#.......#",
			"#.......#",
			".#.....#.",
			"..#####.."
	};

	static final String[] ICON_HAND = {
			"..#.#....",
			"..#.#.#..",
			"#.#.#.#..",
			"#.#####.#",
			"#######.#",
			"########.",
			".######..",
			"..####..."
	};

	private Ui() {
	}

	/** Gefülltes Rechteck mit runden Ecken. Zeilen überlappen nicht, damit Transparenz sauber bleibt. */
	static void round(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
		if (w <= 0 || h <= 0) return;
		r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
		if (r == 0) {
			g.fill(x, y, x + w, y + h, color);
			return;
		}
		for (int i = 0; i < r; i++) {
			double dy = r - i - 0.5;
			int inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy)));
			g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
			g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
		}
		g.fill(x, y + r, x + w, y + h - r, color);
	}

	static void icon(GuiGraphicsExtractor g, String[] icon, int x, int y, int color) {
		for (int row = 0; row < icon.length; row++) {
			String line = icon[row];
			for (int col = 0; col < line.length(); col++) {
				if (line.charAt(col) == '#') {
					g.fill(x + col, y + row, x + col + 1, y + row + 1, color);
				}
			}
		}
	}

	static boolean inside(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	static float approach(float current, float target, float speed) {
		float d = target - current;
		return Math.abs(d) < 0.001F ? target : current + d * speed;
	}
}
