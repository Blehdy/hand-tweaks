package dev.handtweaks.gui;

import dev.handtweaks.HandTweaksConfig;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Cleanes Schwarz-Weiß-Menü. Das Panel sitzt links, damit du rechts live
 * siehst, wie sich das Item in deiner Hand verändert.
 */
public class HandTweaksScreen extends Screen {
	private static final int W = 320;
	private static final int H = 222;

	/** Zuletzt gewählte Hand bleibt beim nächsten Öffnen erhalten. */
	private static boolean editingMain = true;

	private final List<Widget> widgets = new ArrayList<>();
	private Widget dragging;
	private int px;
	private int py;

	public HandTweaksScreen() {
		super(Component.literal("Hand Tweaks"));
	}

	private static HandTweaksConfig cfg() {
		return HandTweaksConfig.get();
	}

	private static HandTweaksConfig.Hand cur() {
		return editingMain ? cfg().mainHand : cfg().offHand;
	}

	/** Nach jeder Änderung: bei gekoppelten Händen die andere Hand mitziehen. */
	private static void changed() {
		HandTweaksConfig c = cfg();
		if (c.linkHands) {
			(editingMain ? c.offHand : c.mainHand).copyFrom(cur());
		}
	}

	// ------------------------------------------------------------------ Layout

	@Override
	protected void init() {
		widgets.clear();
		px = this.width >= W + 40 ? 12 : (this.width - W) / 2;
		py = Math.max(4, (this.height - H) / 2);

		// Seitenleiste
		int sx = px + 6;
		int sy = py + 6;
		int sh = H - 12;
		widgets.add(new HandTab(sx + 2, sy + 4, true));
		widgets.add(new HandTab(sx + 2, sy + 28, false));
		widgets.add(new IconButton(sx + 2, sy + 56, Ui.ICON_RESET, "Diese Hand zurücksetzen",
				() -> false, () -> {
					cur().reset();
					changed();
				}));
		widgets.add(new IconButton(sx + 2, sy + sh - 24, Ui.ICON_POWER, "Mod an/aus",
				() -> cfg().enabled, () -> cfg().enabled = !cfg().enabled));

		// Kopfzeile
		int hx = px + 38;
		widgets.add(new TextTab(hx, py + 10, "Haupthand", true));
		widgets.add(new TextTab(hx + font.width("Haupthand") + 12, py + 10, "Nebenhand", false));
		widgets.add(new Pill(px + W - 8 - 46, py + 7, 46, 15, "Fertig", this::onClose));

		// Inhalt
		int cx = px + 38;
		int cy = py + 28;
		int col = 134;
		int rx = cx + col + 6;

		// Karte: Größe
		widgets.add(new Card(cx, cy, col, 52, "Größe"));
		widgets.add(new Toggle(cx + col - 8 - 20, cy + 6, 20, null,
				() -> cur().enabled, v -> {
					cur().enabled = v;
					changed();
				}));
		widgets.add(new Slider(cx + 8, cy + 22, col - 16, "Skalierung", 0.1F, 3.0F, 0.05F, 1.0F,
				() -> cur().scale, v -> cur().scale = v, v -> String.format(Locale.ROOT, "%.2f×", v)));

		// Karte: Optionen
		int oy = cy + 58;
		int oh = 124;
		widgets.add(new Card(cx, oy, col, oh, "Optionen"));
		widgets.add(new Toggle(cx + 8, oy + 24, col - 16, "Hände koppeln",
				() -> cfg().linkHands, v -> {
					cfg().linkHands = v;
					changed();
				}));
		widgets.add(new Toggle(cx + 8, oy + 42, col - 16, "Auch in 3rd Person",
				() -> cfg().thirdPerson, v -> cfg().thirdPerson = v));
		widgets.add(new Hint(cx + 8, oy + 64, new String[]{
				"Rechtsklick = Reset",
				"Mausrad = fein",
				"Links = gespiegelt"
		}));
		widgets.add(new Pill(cx + 8, oy + oh - 23, col - 16, 15, "Alles zurücksetzen", () -> {
			cfg().mainHand.reset();
			cfg().offHand.reset();
		}));

		// Karte: Neigung
		widgets.add(new Card(rx, cy, col, 88, "Neigung"));
		widgets.add(rotSlider(rx + 8, cy + 20, col - 16, "X  (vor/zurück)", () -> cur().rotX, v -> cur().rotX = v));
		widgets.add(rotSlider(rx + 8, cy + 42, col - 16, "Y  (drehen)", () -> cur().rotY, v -> cur().rotY = v));
		widgets.add(rotSlider(rx + 8, cy + 64, col - 16, "Z  (kippen)", () -> cur().rotZ, v -> cur().rotZ = v));

		// Karte: Position
		int ry = cy + 94;
		widgets.add(new Card(rx, ry, col, 88, "Position"));
		widgets.add(posSlider(rx + 8, ry + 20, col - 16, "X  (links/rechts)", () -> cur().posX, v -> cur().posX = v));
		widgets.add(posSlider(rx + 8, ry + 42, col - 16, "Y  (hoch/runter)", () -> cur().posY, v -> cur().posY = v));
		widgets.add(posSlider(rx + 8, ry + 64, col - 16, "Z  (nah/fern)", () -> cur().posZ, v -> cur().posZ = v));
	}

	private Slider rotSlider(int x, int y, int w, String label, Supplier<Float> get, Consumer<Float> set) {
		return new Slider(x, y, w, label, -180F, 180F, 1F, 0F, get, set,
				v -> String.format(Locale.ROOT, "%d°", Math.round(v)));
	}

	private Slider posSlider(int x, int y, int w, String label, Supplier<Float> get, Consumer<Float> set) {
		return new Slider(x, y, w, label, -1F, 1F, 0.01F, 0F, get, set,
				v -> String.format(Locale.ROOT, "%+.2f", v));
	}

	// ------------------------------------------------------------------ Rendering

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float a) {
		// Kein Blur: die Welt soll sichtbar bleiben, damit man die Hand live sieht.
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		Ui.round(g, px, py, W, H, 10, Ui.PANEL);
		Ui.round(g, px + 6, py + 6, 24, H - 12, 7, Ui.CARD);

		for (Widget w : widgets) {
			w.render(g, font, mouseX, mouseY);
		}

		if (!cfg().enabled) {
			String off = "deaktiviert";
			g.text(font, off, px + W - 8 - 46 - 8 - font.width(off), py + 11, Ui.MUTED, false);
		}

		for (Widget w : widgets) {
			w.tooltip(g, font, mouseX, mouseY);
		}
		super.extractRenderState(g, mouseX, mouseY, delta);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		HandTweaksConfig.save();
		super.onClose();
	}

	// ------------------------------------------------------------------ Input

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		for (Widget w : widgets) {
			if (w.click(event.x(), event.y(), event.button())) {
				if (w instanceof Slider && event.button() == 0) {
					dragging = w;
				}
				return true;
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
		if (dragging != null) {
			dragging.drag(event.x());
			return true;
		}
		return super.mouseDragged(event, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		if (dragging != null) {
			if (dragging instanceof Slider s) {
				s.active = false;
			}
			dragging = null;
			return true;
		}
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		for (Widget w : widgets) {
			if (w.scroll(mouseX, mouseY, scrollY)) {
				return true;
			}
		}
		return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
	}

	// ------------------------------------------------------------------ Widgets

	private abstract static class Widget {
		final int x;
		final int y;
		final int w;
		final int h;

		Widget(int x, int y, int w, int h) {
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
		}

		boolean hovered(double mx, double my) {
			return Ui.inside(mx, my, x, y, w, h);
		}

		abstract void render(GuiGraphicsExtractor g, Font font, int mx, int my);

		void tooltip(GuiGraphicsExtractor g, Font font, int mx, int my) {
		}

		boolean click(double mx, double my, int button) {
			return false;
		}

		void drag(double mx) {
		}

		boolean scroll(double mx, double my, double amount) {
			return false;
		}
	}

	/** Hintergrund-Kachel mit Titel. */
	private static final class Card extends Widget {
		private final String title;

		Card(int x, int y, int w, int h, String title) {
			super(x, y, w, h);
			this.title = title;
		}

		@Override
		void render(GuiGraphicsExtractor g, Font font, int mx, int my) {
			Ui.round(g, x, y, w, h, 7, hovered(mx, my) ? Ui.CARD_HOVER : Ui.CARD);
			g.text(font, title, x + 8, y + 7, Ui.TEXT, false);
		}
	}

	/** Grauer Hinweistext. */
	private static final class Hint extends Widget {
		private final String[] lines;

		Hint(int x, int y, String[] lines) {
			super(x, y, 0, 0);
			this.lines = lines;
		}

		@Override
		void render(GuiGraphicsExtractor g, Font font, int mx, int my) {
			for (int i = 0; i < lines.length; i++) {
				g.text(font, lines[i], x, y + i * 10, Ui.MUTED, false);
			}
		}
	}

	/** Schalter im iOS-Stil: an = weiß mit schwarzem Knopf, aus = grau. */
	private static final class Toggle extends Widget {
		private final String label;
		private final BooleanSupplier get;
		private final Consumer<Boolean> set;
		private float anim = -1F;

		Toggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set) {
			super(x, y, w, 10);
			this.label = label;
			this.get = get;
			this.set = set;
		}

		@Override
		void render(GuiGraphicsExtractor g, Font font, int mx, int my) {
			boolean on = get.getAsBoolean();
			if (anim < 0) anim = on ? 1F : 0F;
			anim = Ui.approach(anim, on ? 1F : 0F, 0.35F);

			int tx = x + w - 20;
			if (label != null) {
				g.text(font, label, x, y + 1, Ui.LABEL, false);
			}
			int bg = lerpColor(0x33FFFFFF, Ui.WHITE, anim);
			Ui.round(g, tx, y, 20, 10, 5, bg);
			int knob = lerpColor(0xFFB0B0B0, Ui.BLACK, anim);
			int kx = tx + 1 + Math.round(anim * 10);
			Ui.round(g, kx, y + 1, 8, 8, 4, knob);
		}

		@Override
		boolean click(double mx, double my, int button) {
			if (button == 0 && Ui.inside(mx, my, x, y - 2, w, h + 4)) {
				set.accept(!get.getAsBoolean());
				return true;
			}
			return false;
		}
	}

	/** Schieberegler mit Beschriftung oben und Wert rechts. */
	private static final class Slider extends Widget {
		private final String label;
		private final float min;
		private final float max;
		private final float step;
		private final float def;
		private final Supplier<Float> get;
		private final Consumer<Float> set;
		private final java.util.function.Function<Float, String> fmt;
		private boolean active;

		Slider(int x, int y, int w, String label, float min, float max, float step, float def,
				Supplier<Float> get, Consumer<Float> set, java.util.function.Function<Float, String> fmt) {
			super(x, y, w, 20);
			this.label = label;
			this.min = min;
			this.max = max;
			this.step = step;
			this.def = def;
			this.get = get;
			this.set = set;
			this.fmt = fmt;
		}

		private int trackY() {
			return y + 14;
		}

		private float t(float v) {
			return (v - min) / (max - min);
		}

		private void apply(float v) {
			v = Math.round(v / step) * step;
			v = Math.max(min, Math.min(max, v));
			set.accept(v);
			changed();
		}

		@Override
		void render(GuiGraphicsExtractor g, Font font, int mx, int my) {
			float v = get.get();
			String value = fmt.apply(v);
			boolean hot = active || hovered(mx, my);

			g.text(font, label, x, y, Ui.LABEL, false);
			g.text(font, value, x + w - font.width(value), y, v == def ? Ui.LABEL : Ui.WHITE, false);

			int ty = trackY();
			Ui.round(g, x, ty, w, 2, 1, Ui.TRACK);

			int knobX = x + Math.round(t(v) * w);
			int originX = x + Math.round(t(min >= 0 ? min : 0F) * w);
			int a = Math.min(knobX, originX);
			int b = Math.max(knobX, originX);
			if (b > a) {
				g.fill(a, ty, b, ty + 2, Ui.WHITE);
			}
			// Mittelstrich für Werte mit Vorzeichen
			if (min < 0) {
				g.fill(originX, ty - 2, originX + 1, ty + 4, 0x55FFFFFF);
			}

			int k = hot ? 8 : 6;
			Ui.round(g, knobX - k / 2, ty + 1 - k / 2, k, k, k / 2, Ui.WHITE);
		}

		@Override
		boolean click(double mx, double my, int button) {
			if (!Ui.inside(mx, my, x - 4, y, w + 8, h)) return false;
			if (button == 1) {
				apply(def);
				return true;
			}
			if (button == 0) {
				active = true;
				drag(mx);
				return true;
			}
			return false;
		}

		@Override
		void drag(double mx) {
			float tt = (float) ((mx - x) / w);
			tt = Math.max(0F, Math.min(1F, tt));
			apply(min + tt * (max - min));
		}

		@Override
		boolean scroll(double mx, double my, double amount) {
			if (!hovered(mx, my) || amount == 0) return false;
			apply(get.get() + (amount > 0 ? step : -step));
			return true;
		}
	}

	/** Abgerundeter Knopf mit Text. */
	private static final class Pill extends Widget {
		private final String text;
		private final Runnable action;

		Pill(int x, int y, int w, int h, String text, Runnable action) {
			super(x, y, w, h);
			this.text = text;
			this.action = action;
		}

		@Override
		void render(GuiGraphicsExtractor g, Font font, int mx, int my) {
			Ui.round(g, x, y, w, h, h / 2, hovered(mx, my) ? Ui.CHIP_HOVER : Ui.CHIP);
			g.text(font, text, x + (w - font.width(text)) / 2, y + (h - 8) / 2, Ui.TEXT, false);
		}

		@Override
		boolean click(double mx, double my, int button) {
			if (button == 0 && hovered(mx, my)) {
				action.run();
				return true;
			}
			return false;
		}
	}

	/** Tabs oben: Haupthand / Nebenhand. */
	private static final class TextTab extends Widget {
		private final String text;
		private final boolean main;

		TextTab(int x, int y, String text, boolean main) {
			super(x, y - 2, 0, 13);
			this.text = text;
			this.main = main;
		}

		@Override
		void render(GuiGraphicsExtractor g, Font font, int mx, int my) {
			boolean sel = editingMain == main;
			int tw = font.width(text);
			boolean hov = Ui.inside(mx, my, x, y, tw, h);
			g.text(font, text, x, y + 2, sel ? Ui.WHITE : (hov ? Ui.LABEL : Ui.MUTED), false);
			if (sel) {
				g.fill(x, y + h, x + tw, y + h + 1, Ui.WHITE);
			}
		}

		@Override
		boolean click(double mx, double my, int button) {
			Font font = net.minecraft.client.Minecraft.getInstance().font;
			if (button == 0 && Ui.inside(mx, my, x, y, font.width(text), h)) {
				editingMain = main;
				return true;
			}
			return false;
		}
	}

	/** Seitenleiste: zeigt das Item, das gerade in der jeweiligen Hand ist. */
	private static final class HandTab extends Widget {
		private final boolean main;

		HandTab(int x, int y, boolean main) {
			super(x, y, 20, 20);
			this.main = main;
		}

		private ItemStack stack() {
			var player = net.minecraft.client.Minecraft.getInstance().player;
			if (player == null) return ItemStack.EMPTY;
			return main ? player.getMainHandItem() : player.getOffhandItem();
		}

		@Override
		void render(GuiGraphicsExtractor g, Font font, int mx, int my) {
			boolean sel = editingMain == main;
			if (sel) {
				Ui.round(g, x, y, w, h, 6, Ui.WHITE);
			} else if (hovered(mx, my)) {
				Ui.round(g, x, y, w, h, 6, Ui.CHIP_HOVER);
			}
			ItemStack s = stack();
			if (s.isEmpty()) {
				Ui.icon(g, Ui.ICON_HAND, x + 6, y + 6, sel ? Ui.BLACK : Ui.LABEL);
			} else {
				g.item(s, x + 2, y + 2);
			}
		}

		@Override
		void tooltip(GuiGraphicsExtractor g, Font font, int mx, int my) {
			if (hovered(mx, my)) {
				g.setTooltipForNextFrame(font, Component.literal(main ? "Haupthand" : "Nebenhand"), mx, my);
			}
		}

		@Override
		boolean click(double mx, double my, int button) {
			if (button == 0 && hovered(mx, my)) {
				editingMain = main;
				return true;
			}
			return false;
		}
	}

	/** Icon-Knopf in der Seitenleiste. */
	private static final class IconButton extends Widget {
		private final String[] icon;
		private final String tip;
		private final BooleanSupplier lit;
		private final Runnable action;

		IconButton(int x, int y, String[] icon, String tip, BooleanSupplier lit, Runnable action) {
			super(x, y, 20, 20);
			this.icon = icon;
			this.tip = tip;
			this.lit = lit;
			this.action = action;
		}

		@Override
		void render(GuiGraphicsExtractor g, Font font, int mx, int my) {
			boolean on = lit.getAsBoolean();
			if (on) {
				Ui.round(g, x, y, w, h, 6, Ui.WHITE);
			} else if (hovered(mx, my)) {
				Ui.round(g, x, y, w, h, 6, Ui.CHIP_HOVER);
			}
			int color = on ? Ui.BLACK : (hovered(mx, my) ? Ui.WHITE : Ui.LABEL);
			Ui.icon(g, icon, x + 6, y + 6, color);
		}

		@Override
		void tooltip(GuiGraphicsExtractor g, Font font, int mx, int my) {
			if (hovered(mx, my)) {
				g.setTooltipForNextFrame(font, Component.literal(tip), mx, my);
			}
		}

		@Override
		boolean click(double mx, double my, int button) {
			if (button == 0 && hovered(mx, my)) {
				action.run();
				return true;
			}
			return false;
		}
	}

	private static int lerpColor(int a, int b, float t) {
		int aa = a >>> 24, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
		int ba = b >>> 24, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
		int oa = Math.round(aa + (ba - aa) * t);
		int or = Math.round(ar + (br - ar) * t);
		int og = Math.round(ag + (bg - ag) * t);
		int ob = Math.round(ab + (bb - ab) * t);
		return (oa << 24) | (or << 16) | (og << 8) | ob;
	}
}
