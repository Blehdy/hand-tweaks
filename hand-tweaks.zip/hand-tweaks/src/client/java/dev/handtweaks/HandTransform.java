package dev.handtweaks;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;

/**
 * Wendet Größe, Neigung und Position auf das Item an, kurz bevor es gezeichnet wird.
 * Für den linken Arm werden X-Position und Y/Z-Rotation gespiegelt, damit dieselben
 * Werte auf beiden Seiten symmetrisch aussehen.
 */
public final class HandTransform {
	private HandTransform() {
	}

	public static HumanoidArm mainArm() {
		return Minecraft.getInstance().options.mainHand().get();
	}

	public static HumanoidArm armOf(InteractionHand hand) {
		HumanoidArm main = mainArm();
		return hand == InteractionHand.MAIN_HAND ? main : main.getOpposite();
	}

	public static InteractionHand handOf(HumanoidArm arm) {
		return arm == mainArm() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
	}

	/** @return true, wenn eine Pose gepusht wurde (dann muss danach popPose() folgen). */
	public static boolean push(PoseStack pose, InteractionHand hand, ItemStack stack) {
		HandTweaksConfig cfg = HandTweaksConfig.get();
		if (!cfg.enabled || stack == null || stack.isEmpty()) {
			return false;
		}

		HandTweaksConfig.Hand h = hand == InteractionHand.MAIN_HAND ? cfg.mainHand : cfg.offHand;
		if (!h.enabled || h.isDefault()) {
			return false;
		}

		float mirror = armOf(hand) == HumanoidArm.LEFT ? -1.0F : 1.0F;

		pose.pushPose();
		pose.translate(h.posX * mirror, h.posY, h.posZ);
		pose.mulPose(Axis.XP.rotationDegrees(h.rotX));
		pose.mulPose(Axis.YP.rotationDegrees(h.rotY * mirror));
		pose.mulPose(Axis.ZP.rotationDegrees(h.rotZ * mirror));
		pose.scale(h.scale, h.scale, h.scale);
		return true;
	}
}
